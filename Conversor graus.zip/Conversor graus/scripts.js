function convertTemperature() {
  const temperature = parseFloat(
    document.getElementById("temperatureInput").value
  );
  const fromUnit = document.getElementById("fromUnit").value;
  const toUnit = document.getElementById("toUnit").value;
  let result;

  if (isNaN(temperature)) {
    document.getElementById("resultOutput").textContent = "--";
    return;
  }

  if (fromUnit === "Celsius" && toUnit === "Fahrenheit") {
    result = (temperature * 9) / 5 + 32;
  } else if (fromUnit === "Fahrenheit" && toUnit === "Celsius") {
    result = ((temperature - 32) * 5) / 9;
  } else if (fromUnit === "Celsius" && toUnit === "Kelvin") {
    result = temperature + 273.15;
  } else if (fromUnit === "Kelvin" && toUnit === "Celsius") {
    result = temperature - 273.15;
  } else if (fromUnit === "Fahrenheit" && toUnit === "Kelvin") {
    result = ((temperature - 32) * 5) / 9 + 273.15;
  } else if (fromUnit === "Kelvin" && toUnit === "Fahrenheit") {
    result = ((temperature - 273.15) * 9) / 5 + 32;
  } else {
    result = temperature;
  }

  result = result.toFixed(2);
  document.getElementById("resultOutput").textContent = result;
  updateBackgroundColor(result);
}

function updateBackgroundColor(temperature) {
  let color;
  if (temperature <= 10) {
    color = "blue";
  } else if (temperature >= 30) {
    color = "red";
  } else {
    color = "yellow";
  }
  document.body.style.backgroundColor = color;
  console.log(
    (innerhtml =
      "https://en.wikipedia.org/wiki/Conversion_of_scales_of_temperature")
  );
}
